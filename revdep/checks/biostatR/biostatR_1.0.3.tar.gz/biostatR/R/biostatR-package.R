#' @keywords internal
#' @importFrom magrittr %>%
"_PACKAGE"

release_questions <- function() {
  c(
    "Have you run `usethis::use_tidy_versions(TRUE)`?"
  )
}
