#' Biostatistics project template
#'
#' The `project_template` object defines the contents of the Biostatistics project
#' template used in `create_msk_project()` and `use_msk_file()`.
#'
#' @format A quoted list defining the Biostatistics project template. Each item of
#' the list identifies one script or document that appears in the project template.
#' @examples
#' mskRutils::create_msk_project(
#'   path = file.path(tempdir(), "Sjoberg New Project"),
#'   template = biostatR::project_template
#' )
#' @seealso `mskRutils::create_msk_project()`
#' @seealso `mskRutils::use_msk_file()`
#' @seealso [Vignette for mskRutils::create_msk_project()](https://github.mskcc.org/pages/datadojo/mskRutils/articles/create_msk_project.html)
"project_template"
