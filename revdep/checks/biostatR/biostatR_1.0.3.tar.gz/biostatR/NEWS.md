# biostatR 1.0.3

* Updated `"biostat"` `.gitignore` project template file to include {renv} folders for `mskRutils::create_msk_project()`

# biostatR 1.0.2

* Update to `"biostat"` project template for `mskRutils::create_msk_project()`

* Updated {gtsummary} dependency to CRAN from GitHub

# biostatR 1.0.1

* Added a project template file that can be used with `mskRutils::create_msk_project()` and `mskRutils::use_msk_project()`

# biostatR 1.0.0

First release since major re-factoring.  The {biostatR} package has been split into three component packages.

- {gtsummary} package creates all summary table functions, inline-text reporting functions, and number formatting functions.

- {mskRvis} package contains the MSKCC color palette that was formally in {biostatR}.  

- {mskRutils} package contains utility functions for working with MSKCC GitHub, symbolic links, and more.

### gtsummary

The {gtsummary} package is now used create all tables, which is powered by the {gt} package (previously {biostatR} utilized {kable}).  Some function names have been modified to be more in line with other {gt} function calls, and additional functions have been added.  The API for some functions has also been updated.  Review documentation and vignettes for details.

#### Updated Function Names

```r
    tbl_summary()                <-  fmt_table1()  
    tbl_regression()             <-  fmt_regression()  
    tbl_uvregression()           <-  fmt_uni_regression()  
    add_p()                      <-  add_comparison()  
    add_global_p()               <-  add_global()  
    style_pvalue()               <-  fmt_pvalue()  
    style_percent()              <-  fmt_percent()  
    style_ratio()                <-  fmt_beta()  
```

#### New Functions

```r
    tbl_survival()          as_gt()  
    tbl_merge()             tbl_stack()
    style_sigfig()          gtsummary_logo()
    add_nevent()            
```
A set of custom [select helper functions](http://www.danieldsjoberg.com/gtsummary/articles/tbl_summary.html#select_helpers) have also been added, as well as the {tidyselect} helper functions.

### mskRvis

The color palette was useful to all groups using R within MSKCC and was added to a package that is for more general purpose.  The package also contains functions for creating MSKCC-themed documents, such as, PowerPoint presentations.

### mskutils

#### Updated Function Names

```r
    create_symlink()    <-  symlink()  
```

# biostatR 0.2.0

- Fixed bug bolding large p-values (#82)

- Various documentation updates

# biostatR 0.1.0

- First public release
