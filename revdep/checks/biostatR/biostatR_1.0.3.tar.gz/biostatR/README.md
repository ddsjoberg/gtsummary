
<!-- README.md is generated from README.Rmd. Please edit that file -->

## biostatR <a href='http://biostatR.mskcc.org'><img src='man/figures/logo.png' align="right" height="130" /></a>

<!-- badges: start -->

<!-- badges: end -->

{biostatR} is a set of packages that work together to report analytic
results with output tailored for members of the Epidemiology and
Biostatistics Department at MSKCC.

<img src="man/figures/biostatrumbrella.png" align="center" width = "45%">

## Installation

1.  Update the {devtools} package
    
    ``` r
    install.packages("devtools")
    ```

2.  Install {biostatR}
    
    ``` r
    devtools::install_git("https://github.mskcc.org/datadojo/biostatR.git")
    ```
    
      - Some systems may require Git to be installed to use
        `devtools::install_git()`. If you get an error stating, `"Git
        does not seem to be installed on your system."`, [download and
        install Git](https://git-scm.com/downloads), restart R, and
        reattempt installation.

3.  Install {gt} from GitHub (recommended)
    
    ``` r
    install.packages("remotes")
    remotes::install_github("rstudio/gt")
    ```
    
      - If you experience issues installing {gt} on Windows, install
        [Rtools from
        CRAN](https://cran.r-project.org/bin/windows/Rtools/), restart
        R, and reattempt installation.

## Usage

`library(biostatR)` will load the following core packages:

  - [gtsummary](http://www.danieldsjoberg.com/gtsummary), Summary Tables
  - [mskRvis](https://github.mskcc.org/pages/datadojo/mskRvis/), MSKCC
    Visualizations and Presentations
  - [mskRutils](https://github.mskcc.org/pages/datadojo/mskRutils/),
    MSKCC System Utilities

<!-- end list -->

``` r
library(biostatR)
#> -- Attaching packages ------------------------------------------------ biostatR 1.0.0 --
#> v gtsummary 1.2.1     v mskRutils 0.2.0
#> v mskRvis   0.2.0
#> 
biostatR_logo()
#> * _ .    o    *  __   .   __  __ 
#>  / /__(_)__ ___ / /_ __ _/ /_/ _ \
#> / _  / / _ (_-</ __/ _ `/ __/ , _/
#> \_,_/_/_,_/___/\__/\_,_/\__/_/|_| 
#>   *        .      o  .        *
```

You can see conflicts created later with `biostatR_conflicts()`.

#### Installation of Previous Version

To use the previous version of {biostatR}, use the following code to
install the version of {biostatR} before the uncoupling.

``` r
remotes::install_git("https://github.mskcc.org/datadojo/biostatR.git", ref = "v0.2.0")
```
